import React, { useState, useRef } from "react";
import {
  View,
  Text,
  TextInput,
  Button,
  StyleSheet,
  Image,
  Alert,
  Pressable,
} from "react-native";
import { NavigationContainer } from "@react-navigation/native";
import { createStackNavigator } from "@react-navigation/stack";

const Stack = createStackNavigator();

// -------------------- LOGIN --------------------
function LoginScreen({ navigation }) {
  const [email, setEmail] = useState("");
  const [senha, setSenha] = useState("");

  const isFormValid = email.trim() !== "" && senha.trim() !== "";

  const handleLogin = () => {
    Alert.alert("Login realizado com sucesso!");
  };

  return (
    <View style={styles.container}>
      {/* Logo */}
      <Image
        source={{
          uri: "https://imgs.search.brave.com/2IAhKMjLGZFowSS8bLgpiZplfWtO9YCSHNUnSROdVOc/rs:fit:860:0:0:0/g:ce/aHR0cHM6Ly9pbWFn/ZXMzLmFscGhhY29k/ZXJzLmNvbS8xMjAv/dGh1bWItMTkyMC0x/MjA2NDMzLmpwZw",
        }}
        style={styles.logo}
      />

      <Text style={styles.label}>E-mail</Text>
      <TextInput
        style={styles.input}
        placeholder="Digite seu e-mail"
        keyboardType="email-address"
        value={email}
        onChangeText={setEmail}
      />

      <Text style={styles.label}>Senha</Text>
      <TextInput
        style={styles.input}
        placeholder="Digite sua senha"
        secureTextEntry
        value={senha}
        onChangeText={setSenha}
      />

      <View style={styles.buttonContainer}>
        <Button title="ENTRAR" onPress={handleLogin} disabled={!isFormValid} />
      </View>

      <Pressable onPress={() => navigation.navigate("Cadastro")}>
        <Text style={styles.link}>Registrar-se</Text>
      </Pressable>

      <Pressable onPress={() => navigation.navigate("RedefinirSenha")}>
        <Text style={styles.link}>Redefinir a Senha</Text>
      </Pressable>
    </View>
  );
}

// -------------------- CADASTRO --------------------
function CadastroScreen({ navigation }) {
  const [cpf, setCpf] = useState("");
  const [nome, setNome] = useState("");
  const [email, setEmail] = useState("");
  const [senha, setSenha] = useState("");

  const isValid = cpf && nome && email && senha;

  const handleSave = () => {
    Alert.alert("Sucesso", "Usuário registrado com sucesso");
    navigation.navigate("Login");
  };

  return (
    <View style={styles.container}>
      <Text style={styles.title}>Cadastro de Usuário</Text>

      <Text style={styles.label}>CPF</Text>
      <TextInput style={styles.input} value={cpf} onChangeText={setCpf} />

      <Text style={styles.label}>Nome</Text>
      <TextInput style={styles.input} value={nome} onChangeText={setNome} />

      <Text style={styles.label}>E-mail</Text>
      <TextInput
        style={styles.input}
        value={email}
        onChangeText={setEmail}
        keyboardType="email-address"
      />

      <Text style={styles.label}>Senha</Text>
      <TextInput
        style={styles.input}
        value={senha}
        onChangeText={setSenha}
        secureTextEntry
      />

      <View style={styles.buttonContainer}>
        <Button title="Salvar" onPress={handleSave} disabled={!isValid} />
      </View>

      <Pressable onPress={() => navigation.navigate("Login")}>
        <Text style={styles.link}>Voltar para Login</Text>
      </Pressable>
    </View>
  );
}

// -------------------- REDEFINIR SENHA --------------------
function RedefinirSenhaScreen({ navigation }) {
  const [senha, setSenha] = useState("");
  const [confirmar, setConfirmar] = useState("");
  const senhaRef = useRef(null);

  const handleSave = () => {
    if (senha !== confirmar) {
      Alert.alert("Erro", "Senhas não são iguais");
      senhaRef.current.focus();
      return;
    }
    Alert.alert("Sucesso", "Senha redefinida com sucesso");
    navigation.navigate("Login");
  };

  return (
    <View style={styles.container}>
      <Text style={styles.title}>Redefinir Senha</Text>

      <Text style={styles.label}>Nova Senha</Text>
      <TextInput
        ref={senhaRef}
        style={styles.input}
        value={senha}
        onChangeText={setSenha}
        secureTextEntry
      />

      <Text style={styles.label}>Confirmar Senha</Text>
      <TextInput
        style={styles.input}
        value={confirmar}
        onChangeText={setConfirmar}
        secureTextEntry
      />

      <View style={styles.buttonContainer}>
        <Button title="Salvar" onPress={handleSave} />
      </View>

      <Pressable onPress={() => navigation.navigate("Login")}>
        <Text style={styles.link}>Voltar para Login</Text>
      </Pressable>
    </View>
  );
}

// -------------------- APP --------------------
export default function App() {
  return (
    <NavigationContainer>
      <Stack.Navigator initialRouteName="Login">
        <Stack.Screen name="Login" component={LoginScreen} />
        <Stack.Screen name="Cadastro" component={CadastroScreen} />
        <Stack.Screen name="RedefinirSenha" component={RedefinirSenhaScreen} />
      </Stack.Navigator>
    </NavigationContainer>
  );
}

// -------------------- ESTILOS --------------------
const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: "center",
    alignItems: "center",
    padding: 20,
    backgroundColor: "#f0f0f0",
  },
  logo: {
    width: 80,
    height: 80,
    marginBottom: 30,
  },
  title: {
    fontSize: 22,
    marginBottom: 20,
    fontWeight: "bold",
  },
  label: {
    alignSelf: "flex-start",
    marginLeft: 10,
    marginBottom: 5,
    fontSize: 16,
    fontWeight: "bold",
  },
  input: {
    width: "100%",
    height: 45,
    borderWidth: 1,
    borderColor: "#ccc",
    borderRadius: 8,
    paddingHorizontal: 10,
    backgroundColor: "#fff",
    marginBottom: 15,
  },
  buttonContainer: {
    width: "100%",
    marginBottom: 20,
  },
  link: {
    color: "blue",
    marginTop: 10,
    textDecorationLine: "underline",
  },
});
