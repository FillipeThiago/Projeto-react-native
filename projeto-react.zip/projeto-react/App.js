import React, { useState } from "react";
import { 
  View, 
  Text, 
  TextInput, 
  Button, 
  StyleSheet, 
  Image, 
  Alert, 
  Pressable 
} from "react-native";

export default function App() {
  const [email, setEmail] = useState("");
  const [senha, setSenha] = useState("");

  const isFormValid = email.trim() !== "" && senha.trim() !== "";

  const handleLogin = () => {
    Alert.alert("Login realizado com sucesso!");
  };

  const handleRegister = () => {
    Alert.alert("Tela de Registro em breve!");
  };

  const handleResetPassword = () => {
    Alert.alert("Tela de redefinição de senha em breve!");
  };

  return (
    <View style={styles.container}>
      {/* Logo / Imagem */}
      <Image
        source={{ uri: "https://imgs.search.brave.com/2IAhKMjLGZFowSS8bLgpiZplfWtO9YCSHNUnSROdVOc/rs:fit:860:0:0:0/g:ce/aHR0cHM6Ly9pbWFn/ZXMzLmFscGhhY29k/ZXJzLmNvbS8xMjAv/dGh1bWItMTkyMC0x/MjA2NDMzLmpwZw" }}
        style={styles.logo}
      />

      {/* Campo de e-mail */}
      <Text style={styles.label}>E-mail</Text>
      <TextInput
        style={styles.input}
        placeholder="Digite seu e-mail"
        keyboardType="email-address"
        value={email}
        onChangeText={setEmail}
      />

      {/* Campo de senha */}
      <Text style={styles.label}>Senha</Text>
      <TextInput
        style={styles.input}
        placeholder="Digite sua senha"
        secureTextEntry
        value={senha}
        onChangeText={setSenha}
      />

      {/* Botão de Login */}
      <View style={styles.buttonContainer}>
        <Button 
          title="ENTRAR" 
          onPress={handleLogin} 
          disabled={!isFormValid} 
        />
      </View>

      {/* Links */}
      <Pressable onPress={handleRegister}>
        <Text style={styles.link}>Registrar-se</Text>
      </Pressable>

      <Pressable onPress={handleResetPassword}>
        <Text style={styles.link}>Redefinir a Senha</Text>
      </Pressable>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: "center",
    alignItems: "center",
    padding: 20,
    backgroundColor: "#f0f0f0",
  },
  logo: {
    width: 80,
    height: 80,
    marginBottom: 30,
  },
  label: {
    alignSelf: "flex-start",
    marginLeft: 10,
    marginBottom: 5,
    fontSize: 16,
    fontWeight: "bold",
  },
  input: {
    width: "100%",
    height: 45,
    borderWidth: 1,
    borderColor: "#ccc",
    borderRadius: 8,
    paddingHorizontal: 10,
    backgroundColor: "#fff",
    marginBottom: 15,
  },
  buttonContainer: {
    width: "100%",
    marginBottom: 20,
  },
  link: {
    color: "blue",
    marginTop: 10,
    textDecorationLine: "underline",
  },
});
